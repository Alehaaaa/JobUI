# -*- coding: utf-8 -*-
"""The viewport: a QGraphicsView whose scene is in native video pixels.

A single pixmap item displays decoded frames from the native video sink,
FFmpeg streaming fallback, or an image sequence. Using one item for both means playback renders through the same
reliable path as the poster, instead of a QGraphicsVideoItem that some drivers
leave black. The crop rectangle sits on top, in native pixel coordinates, so
there is no hand-rolled coordinate mapping anywhere.
"""
from __future__ import absolute_import

import os

from .qtcompat import QtCore, QtGui, QtWidgets, Signal
from . import style, utils


class PlaybackSurface(QtWidgets.QGraphicsView):
    cropChanged = Signal(object)        # QRectF in native pixels, or None
    scrubRequested = Signal(int)        # +/- frame delta from the wheel
    mediaDropped = Signal(str)          # path dropped onto the viewport
    importRequested = Signal()          # placeholder button clicked

    def __init__(self, parent=None):
        QtWidgets.QGraphicsView.__init__(self, parent)
        self.setScene(QtWidgets.QGraphicsScene(self))
        self.setRenderHint(QtGui.QPainter.SmoothPixmapTransform, True)
        self.setBackgroundBrush(QtGui.QColor(style.BG))
        self.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.setMouseTracking(True)
        self.setAcceptDrops(True)

        self._native = QtCore.QSizeF(0, 0)
        self._flip_h = False
        self._flip_v = False

        self.frame_item = QtWidgets.QGraphicsPixmapItem()
        self.frame_item.setTransformationMode(QtCore.Qt.SmoothTransformation)
        self.scene().addItem(self.frame_item)

        self._crop = QtWidgets.QGraphicsRectItem()
        pen = QtGui.QPen(QtGui.QColor(style.CROP))
        pen.setCosmetic(True)
        pen.setWidth(1)
        self._crop.setPen(pen)
        self._crop.setBrush(QtGui.QColor(82, 133, 166, 40))
        self._crop.setZValue(10)
        self.scene().addItem(self._crop)
        self._crop.hide()
        self._crop_hidden = False
        self._has_crop = False

        self._drag = None
        self._placeholder = self._build_placeholder()

    # -- empty-state placeholder -----------------------------------------
    def _build_placeholder(self):
        frame = QtWidgets.QFrame(self)
        frame.setObjectName('vcPlaceholder')
        layout = QtWidgets.QVBoxLayout(frame)
        layout.setContentsMargins(28, 24, 28, 24)
        layout.setSpacing(10)
        layout.setAlignment(QtCore.Qt.AlignCenter)
        icon = QtWidgets.QLabel('⬇')
        icon.setAlignment(QtCore.Qt.AlignCenter)
        font = icon.font()
        font.setPointSize(max(font.pointSize(), 21))
        icon.setFont(font)
        caption = QtWidgets.QLabel('Drag a video here')
        caption.setAlignment(QtCore.Qt.AlignCenter)
        caption.setProperty('dim', True)
        button = QtWidgets.QPushButton('Import Media…')
        button.clicked.connect(self.importRequested.emit)
        layout.addWidget(icon)
        layout.addWidget(caption)
        layout.addWidget(button, 0, QtCore.Qt.AlignCenter)
        frame.adjustSize()
        return frame

    def set_placeholder_visible(self, visible):
        self._placeholder.setVisible(visible)
        self._position_placeholder()

    def _position_placeholder(self):
        size = self._placeholder.sizeHint()
        self._placeholder.resize(size)
        self._placeholder.move((self.width() - size.width()) // 2,
                               (self.height() - size.height()) // 2)

    # -- drag and drop ----------------------------------------------------
    def _dropped_path(self, event):
        mime = event.mimeData()
        if not mime.hasUrls():
            return None
        for url in mime.urls():
            path = url.toLocalFile()
            if path and os.path.splitext(path)[1].lower() in (utils.IMAGE_EXTS + utils.VIDEO_EXTS):
                return path
        return None

    def dragEnterEvent(self, event):
        event.acceptProposedAction() if self._dropped_path(event) else event.ignore()

    def dragMoveEvent(self, event):
        event.acceptProposedAction() if self._dropped_path(event) else event.ignore()

    def dropEvent(self, event):
        path = self._dropped_path(event)
        if path:
            event.acceptProposedAction()
            self.mediaDropped.emit(path)
        else:
            event.ignore()

    # -- media geometry / display ----------------------------------------
    def set_native_size(self, width, height):
        self._native = QtCore.QSizeF(width, height)
        self.scene().setSceneRect(0, 0, width, height)
        self._fit()

    def set_display(self, pixmap):
        """Show a pixmap (live frame or poster still), scaled+flipped to native."""
        if pixmap is None or pixmap.isNull():
            return
        self.frame_item.setPixmap(pixmap)
        self._apply_frame_transform()

    def clear(self):
        self.frame_item.setPixmap(QtGui.QPixmap())
        self.set_crop(None)

    def set_flip(self, flip_h, flip_v):
        self._flip_h, self._flip_v = bool(flip_h), bool(flip_v)
        self._apply_frame_transform()

    def _apply_frame_transform(self):
        """Map the pixmap onto the native rect, mirrored as needed. The crop
        item stays in native coords, matching ffmpeg's flip-then-crop order."""
        pixmap = self.frame_item.pixmap()
        if pixmap.isNull() or self._native.isEmpty() or not pixmap.width() or not pixmap.height():
            return
        sx = self._native.width() / pixmap.width()
        sy = self._native.height() / pixmap.height()
        transform = QtGui.QTransform()
        if self._flip_h:
            transform.translate(self._native.width(), 0)
            transform.scale(-1, 1)
        if self._flip_v:
            transform.translate(0, self._native.height())
            transform.scale(1, -1)
        transform.scale(sx, sy)
        self.frame_item.setTransform(transform)

    # -- crop rectangle (native pixels) -----------------------------------
    def crop(self):
        if not self._has_crop:
            return None
        rect = self._crop.rect()
        return (int(round(rect.x())), int(round(rect.y())),
                int(round(rect.width())), int(round(rect.height())))

    def set_crop(self, rect, notify=True):
        """rect is (x, y, w, h) in native pixels, a QRectF, or None."""
        bounds = QtCore.QRectF(0, 0, self._native.width(), self._native.height())
        if rect is None or bounds.isEmpty():
            self._has_crop = False
            self._crop.hide()
            if notify:
                self.cropChanged.emit(None)
            return
        if not isinstance(rect, QtCore.QRectF):
            x, y, w, h = rect
            rect = QtCore.QRectF(x, y, w, h)
        rect = rect.normalized().intersected(bounds)
        if rect.width() < 2 or rect.height() < 2:
            self._has_crop = False
            self._crop.hide()
            if notify:
                self.cropChanged.emit(None)
            return
        self._has_crop = True
        self._crop.setRect(rect)
        self._crop.setVisible(not self._crop_hidden)
        if notify:
            self.cropChanged.emit(QtCore.QRectF(rect))

    def set_crop_visible(self, visible):
        self._crop_hidden = not visible
        self._crop.setVisible(visible and self._has_crop)

    # -- view behaviour ---------------------------------------------------
    def _fit(self):
        if not self._native.isEmpty():
            self.fitInView(self.sceneRect(), QtCore.Qt.KeepAspectRatio)

    def resizeEvent(self, event):
        QtWidgets.QGraphicsView.resizeEvent(self, event)
        self._fit()
        self._position_placeholder()

    def showEvent(self, event):
        QtWidgets.QGraphicsView.showEvent(self, event)
        self._position_placeholder()

    def mousePressEvent(self, event):
        if event.button() == QtCore.Qt.RightButton:
            self.set_crop(None)
            event.accept()
            return
        if event.button() == QtCore.Qt.LeftButton and not self._native.isEmpty():
            point = self.mapToScene(event.pos())
            current = self._crop.rect() if self._has_crop else None
            if current is not None and current.contains(point):
                self._drag = ('move', point, QtCore.QRectF(current))
            else:
                self._drag = ('draw', point, None)
                self.set_crop(None)
            event.accept()
            return
        QtWidgets.QGraphicsView.mousePressEvent(self, event)

    def mouseMoveEvent(self, event):
        if self._drag:
            kind, start, original = self._drag
            point = self.mapToScene(event.pos())
            if kind == 'move':
                bounds = self.sceneRect()
                moved = QtCore.QRectF(original)
                moved.translate(point - start)
                moved.moveLeft(utils.clamp(moved.left(), 0, bounds.width() - moved.width()))
                moved.moveTop(utils.clamp(moved.top(), 0, bounds.height() - moved.height()))
                self.set_crop(moved)
            else:
                self.set_crop(QtCore.QRectF(start, point))
            event.accept()
            return
        QtWidgets.QGraphicsView.mouseMoveEvent(self, event)

    def mouseReleaseEvent(self, event):
        self._drag = None
        QtWidgets.QGraphicsView.mouseReleaseEvent(self, event)

    def wheelEvent(self, event):
        step = 10 if event.modifiers() & QtCore.Qt.ShiftModifier else 1
        self.scrubRequested.emit(step if event.angleDelta().y() > 0 else -step)
        event.accept()
