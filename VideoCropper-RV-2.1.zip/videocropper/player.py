# -*- coding: utf-8 -*-
"""Stable, frame-addressed playback with a single presentation surface.

Qt6 uses native decoding through QVideoSink, copying decoded frames to the
same pixmap item used by stills and image sequences. If that decoder does not
deliver a frame, or multimedia is unavailable (including Maya's Qt5 builds),
playback moves to the bounded asynchronous FFmpeg frame source.

The visible image is never cleared during pause, seek, trim-loop or buffering.
"""
from __future__ import absolute_import

from .qtcompat import QtCore, QtGui, Signal, HAVE_MULTIMEDIA, QMediaPlayer, QVideoSink, QAudioOutput
from . import utils
from .frames import SequenceSource, VideoFrameSource, FramePump


class Player(QtCore.QObject):
    frameChanged = Signal(int)
    playingChanged = Signal(bool)
    loaded = Signal()
    errorText = Signal(str)

    def __init__(self, ffmpeg, surface, parent=None):
        QtCore.QObject.__init__(self, parent)
        self._ffmpeg = ffmpeg
        self.surface = surface

        self.info = None
        self.fps = 24.0
        self.frame_count = 1
        self.current_frame = 0
        self.in_frame = 0
        self.out_frame = 0
        self.loop = False
        self.speed = 1.0
        self.playing = False

        self._backend = None
        self._qplayer = None
        self._sink = None
        self._audio = None
        self._pump = None
        self._source = None
        self._pending_position = None
        self._got_video_frame = False
        self._preparing = False
        self._seek_target_us = None
        self._loop_seeking = False
        self._last_emitted = -1
        self._watchdog = QtCore.QTimer(self)
        self._watchdog.setSingleShot(True)
        self._watchdog.timeout.connect(self._check_decoder)

    def load(self, info):
        self.stop_all()
        self.info = info
        self.fps = info.fps
        self.frame_count = info.frame_count
        self.current_frame = 0
        self.in_frame = 0
        self.out_frame = info.frame_count - 1
        self.playing = False
        self._last_emitted = -1
        self._pending_position = None
        self._got_video_frame = False
        self._preparing = False
        self._seek_target_us = None
        self._loop_seeking = False
        self.surface.set_native_size(info.width, info.height)
        self.surface.clear()

        if not info.is_sequence and HAVE_MULTIMEDIA and QVideoSink is not None:
            try:
                self._build_qplayer(info.path)
                self._backend = 'qt'
                self._pending_position = 0
                # Let the decoder present its first real frame, then pause.
                # This uses the regular player pipeline, not a still extractor.
                self._preparing = True
                self._watchdog.start(2500)
                self._qplayer.play()
            except Exception as exc:
                self._stop_qplayer()
                self.errorText.emit('Native decoder unavailable: {}'.format(exc))
                self._activate_frames(0)
        else:
            self._activate_frames(0)
        self._emit_frame(0)
        self.loaded.emit()

    def _build_qplayer(self, path):
        self._sink = QVideoSink(self)
        self._sink.videoFrameChanged.connect(self._on_video_frame)
        self._qplayer = QMediaPlayer(self)
        self._qplayer.setVideoOutput(self._sink)
        if QAudioOutput is not None:
            self._audio = QAudioOutput(self)
            self._audio.setVolume(0.5)
            self._qplayer.setAudioOutput(self._audio)
        self._qplayer.positionChanged.connect(self._on_position)
        self._qplayer.mediaStatusChanged.connect(self._on_media_status)
        if hasattr(self._qplayer, 'errorOccurred'):
            self._qplayer.errorOccurred.connect(self._on_decoder_error)
        self._qplayer.setSource(QtCore.QUrl.fromLocalFile(path))
        self._qplayer.setPlaybackRate(self.speed)

    def _activate_frames(self, frame):
        """Create a fresh fallback after destroying the old decoder."""
        self._watchdog.stop()
        self._preparing = False
        self._seek_target_us = None
        self._backend = 'frames'
        self._stop_qplayer()
        info = self.info
        if info.is_sequence:
            self._source = SequenceSource(info.sequence_files, self)
        else:
            self._source = VideoFrameSource(
                self._ffmpeg, info.path, info.fps, info.frame_count, self)
            self._source.errorText.connect(self._on_frame_error)
        self._source.frameAvailable.connect(self._on_frame_available)
        self._source.set_loop_start(self.in_frame)
        self._pump = FramePump(self._source, self.fps, self)
        self._pump.in_frame = self.in_frame
        self._pump.out_frame = self.out_frame
        self._pump.loop = self.loop
        self._pump.set_speed(self.speed)
        self._pump.frameChanged.connect(self._on_pump_frame)
        self._pump.stopped.connect(lambda: self._set_playing(False))
        self._pump.seek(frame)
        self._on_frame_available(frame)

    def _on_source_error(self, message):
        self.pause()
        self.errorText.emit(message)

    def _on_video_frame(self, video_frame):
        if self._backend != 'qt' or not video_frame.isValid():
            return
        try:
            image = video_frame.toImage()
            if image.isNull():
                return
            if self._seek_target_us is not None:
                timestamp = video_frame.startTime()
                if timestamp >= 0:
                    # Frames from the old decoder queue must never overwrite the
                    # last good frame during a seek, especially at loop wrap.
                    if abs(timestamp - self._seek_target_us) > 100000:
                        return
                self._seek_target_us = None
            self.surface.set_display(QtGui.QPixmap.fromImage(image))
        except Exception:
            return
        self._got_video_frame = True
        self._watchdog.stop()
        if self._preparing and not self.playing:
            self._preparing = False
            self._qplayer.pause()

    def _on_position(self, ms):
        if self._backend != 'qt':
            return
        frame = int(utils.clamp(utils.ms_to_frame(ms, self.fps), 0, self.frame_count - 1))
        if self._loop_seeking:
            if frame <= self.in_frame + 1:
                self._loop_seeking = False
            else:
                return
        if self.playing and frame >= self.out_frame:
            if self.loop and self.out_frame > self.in_frame:
                self._loop_seeking = True
                self._seek_target_us = int(self.in_frame / self.fps * 1000000)
                self._qplayer.setPosition(int(utils.frame_to_ms(self.in_frame, self.fps)))
                return
            self._pause_at(self.out_frame)
            return
        self.current_frame = frame
        self._emit_frame(frame)

    def _on_media_status(self, status):
        if self._backend != 'qt':
            return
        try:
            loaded = status in (QMediaPlayer.MediaStatus.LoadedMedia,
                                QMediaPlayer.MediaStatus.BufferedMedia)
            ended = status == QMediaPlayer.MediaStatus.EndOfMedia
        except AttributeError:
            return
        if loaded and self._pending_position is not None:
            self._qplayer.setPosition(int(self._pending_position))
            self._pending_position = None
        if ended:
            if self.loop and self.playing:
                self._loop_seeking = False
                self._seek_target_us = int(self.in_frame / self.fps * 1000000)
                self._qplayer.setPosition(int(utils.frame_to_ms(self.in_frame, self.fps)))
                self._qplayer.play()
            elif self.playing:
                self._pause_at(self.out_frame)

    def _on_decoder_error(self, *args):
        if self._backend != 'qt' or self.info is None:
            return
        message = self._qplayer.errorString() or 'Native video decoder error'
        was_playing = self.playing
        frame = self.current_frame
        self._activate_frames(frame)
        if was_playing:
            self._pump.play()
        self.errorText.emit('Using FFmpeg decoder: ' + message)

    def _check_decoder(self):
        if self._backend == 'qt' and (self.playing or self._preparing) and not self._got_video_frame:
            frame = self.current_frame
            self._activate_frames(frame)
            if self.playing:
                self._pump.play()

    def _on_frame_error(self, message):
        self.pause()
        self.errorText.emit(message)

    def _on_pump_frame(self, frame):
        self.current_frame = frame
        pixmap = self._pump.pixmap() if self._pump is not None else None
        if pixmap is not None:
            self.surface.set_display(pixmap)
        self._emit_frame(frame)

    def _on_frame_available(self, frame):
        if self._backend != 'frames' or frame != self.current_frame:
            return
        pixmap = self._source.get(frame) if self._source is not None else None
        if pixmap is not None:
            self.surface.set_display(pixmap)

    def play(self):
        if self.info is None or self.playing:
            return
        if self.current_frame >= self.out_frame and self.out_frame > self.in_frame:
            self.seek(self.in_frame)
        self._preparing = False
        self._set_playing(True)
        if self._backend == 'qt':
            self._got_video_frame = False
            self._watchdog.start(2500)
            self._qplayer.play()
        elif self._pump is not None:
            self._pump.play()

    def pause(self):
        if self._backend == 'qt' and self._qplayer is not None:
            self._qplayer.pause()
        elif self._pump is not None:
            self._pump.pause()
        self._watchdog.stop()
        self._preparing = False
        self._set_playing(False)

    def toggle(self):
        if self.playing:
            self.pause()
        else:
            self.play()

    def _pause_at(self, frame):
        if self._backend == 'qt' and self._qplayer is not None:
            self._qplayer.pause()
        self._watchdog.stop()
        self._set_playing(False)
        self.current_frame = int(utils.clamp(frame, 0, self.frame_count - 1))
        self._emit_frame(self.current_frame)

    def seek(self, frame):
        if self.info is None:
            return
        frame = int(utils.clamp(frame, self.in_frame, self.out_frame))
        self.current_frame = frame
        if self._backend == 'qt' and self._qplayer is not None:
            self._loop_seeking = False
            pos = int(utils.frame_to_ms(frame, self.fps))
            self._seek_target_us = int(frame / self.fps * 1000000)
            if self._pending_position is not None:
                self._pending_position = pos
            else:
                self._qplayer.setPosition(pos)
        elif self._pump is not None:
            self._pump.seek(frame)
        self._emit_frame(frame)

    def set_range(self, in_frame, out_frame):
        lo = int(utils.clamp(min(in_frame, out_frame), 0, self.frame_count - 1))
        hi = int(utils.clamp(max(in_frame, out_frame), lo, self.frame_count - 1))
        self.in_frame, self.out_frame = lo, hi
        if self._pump is not None:
            self._pump.in_frame = lo
            self._pump.out_frame = hi
        if self._source is not None:
            self._source.set_loop_start(lo)
        self.seek(utils.clamp(self.current_frame, lo, hi))

    def set_loop(self, enabled):
        self.loop = bool(enabled)
        if self._pump is not None:
            self._pump.loop = self.loop

    def set_speed(self, speed):
        self.speed = max(0.01, float(speed))
        if self._backend == 'qt' and self._qplayer is not None:
            self._qplayer.setPlaybackRate(self.speed)
        elif self._pump is not None:
            self._pump.set_speed(self.speed)

    def _set_playing(self, value):
        if value != self.playing:
            self.playing = value
            self.playingChanged.emit(value)

    def _emit_frame(self, frame):
        if frame != self._last_emitted:
            self._last_emitted = frame
            self.frameChanged.emit(frame)

    def _stop_qplayer(self):
        if self._qplayer is not None:
            try:
                self._qplayer.stop()
                self._qplayer.setVideoOutput(None)
            except (RuntimeError, TypeError):
                pass
            self._qplayer.deleteLater()
            self._qplayer = None
        if self._sink is not None:
            self._sink.deleteLater()
            self._sink = None
        if self._audio is not None:
            self._audio.deleteLater()
            self._audio = None

    def stop_all(self):
        self._watchdog.stop()
        self._preparing = False
        self._backend = None
        self._seek_target_us = None
        self._set_playing(False)
        self._stop_qplayer()
        if self._pump is not None:
            self._pump.pause()
            self._pump.deleteLater()
            self._pump = None
        if self._source is not None:
            self._source.shutdown()
            self._source.deleteLater()
            self._source = None

    def shutdown(self):
        self.stop_all()
