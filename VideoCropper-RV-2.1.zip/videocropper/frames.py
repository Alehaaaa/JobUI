# -*- coding: utf-8 -*-
"""Bounded frame caches and asynchronous frame decoding for Maya.

FFmpeg pipes compressed JPEGs directly into memory. There are no temporary
frame directories, per-frame subprocesses, blocking thread joins, or polling
of the filesystem. Decoder requests are guarded by process identity so stale output
cannot enter the cache after a seek or media change.
"""
from __future__ import absolute_import

import collections

from .qtcompat import QtCore, QtGui, Signal
from . import utils
from .ffmpegtools import configure_process

DECODE_WIDTH = 960
CACHE_BYTES = 144 * 1024 * 1024
BATCH_SIZE = 48
CACHE_FRAMES = 64
PREFETCH_THRESHOLD = 12


def _split_jpegs(buffer):
    """Extract complete images from a possibly fragmented MJPEG pipe."""
    frames = []
    offset = 0
    while True:
        start = buffer.find(b'\xff\xd8', offset)
        if start < 0:
            break
        end = buffer.find(b'\xff\xd9', start + 2)
        if end < 0:
            return frames, buffer[start:]
        frames.append(bytes(buffer[start:end + 2]))
        offset = end + 2
    return frames, bytearray()


def _stop_process(proc):
    """Retire a QProcess without blocking Maya's UI thread."""
    if proc is not None:
        try:
            if proc.state() != QtCore.QProcess.NotRunning:
                proc.kill()
        except RuntimeError:
            pass
        # The finished signal retains its own cleanup connection.
        # Deleting a still-running QProcess synchronously can stall Maya.


class SequenceSource(QtCore.QObject):
    """Sequence reader with scaled images and a byte-bounded display cache."""
    frameAvailable = Signal(int)

    def __init__(self, files, parent=None):
        QtCore.QObject.__init__(self, parent)
        self._files = list(files)
        self._cache = collections.OrderedDict()
        self._cache_bytes = 0

    def get(self, frame):
        if frame in self._cache:
            self._cache.move_to_end(frame)
            return self._cache[frame]
        if not (0 <= frame < len(self._files)):
            return None
        reader = QtGui.QImageReader(self._files[frame])
        original = reader.size()
        if original.isValid() and original.width() > DECODE_WIDTH:
            target_height = max(1, int(original.height() * DECODE_WIDTH / original.width()))
            reader.setScaledSize(QtCore.QSize(DECODE_WIDTH, target_height))
        image = reader.read()
        if image.isNull():
            return None
        if image.width() > DECODE_WIDTH:
            image = image.scaledToWidth(DECODE_WIDTH, QtCore.Qt.SmoothTransformation)
        pixmap = QtGui.QPixmap.fromImage(image)
        self._cache[frame] = pixmap
        self._cache_bytes += pixmap.width() * pixmap.height() * 4
        while len(self._cache) > 32 or self._cache_bytes > CACHE_BYTES:
            _, evicted = self._cache.popitem(last=False)
            self._cache_bytes -= evicted.width() * evicted.height() * 4
        return pixmap

    def ensure(self, frame):
        return

    def set_loop_start(self, frame):
        return

    def shutdown(self):
        self._cache.clear()
        self._cache_bytes = 0


class VideoFrameSource(QtCore.QObject):
    """Seekable FFmpeg batch decoder; QProcess never blocks the UI.

    One decoder streams at most BATCH_SIZE small frames at a time. A bounded
    pixmap LRU is enough to cover normal scheduling jitter. The first eight
    frames from the loop start remain pinned for instant repeat playback.
    """
    frameAvailable = Signal(int)
    errorText = Signal(str)

    def __init__(self, ffmpeg, source, fps, frame_count, parent=None):
        QtCore.QObject.__init__(self, parent)
        self._ffmpeg = ffmpeg
        self._source = source
        self._fps = max(0.001, float(fps))
        self._frame_count = max(1, int(frame_count))
        self._cache = collections.OrderedDict()
        self._cache_bytes = 0
        self._proc = None
        self._retired = set()
        self._buffer = bytearray()
        self._next_frame = 0
        self._batch_start = -1
        self._batch_end = -1
        self._loop_start = 0
        self._failed = False
        self._error_reported = False

    def set_loop_start(self, frame):
        self._loop_start = int(frame)

    def get(self, frame):
        image = self._cache.get(frame)
        if image is not None:
            self._cache.move_to_end(frame)
        return image

    def ensure(self, frame):
        if self._failed:
            return
        frame = int(utils.clamp(frame, 0, self._frame_count - 1))
        in_flight = self._proc is not None
        if self.get(frame) is None:
            if not in_flight or frame < self._batch_start or frame > self._batch_end:
                self._launch(frame)
            return

        # The next batch starts before playback exhausts the current one.
        if (not in_flight and self._batch_end >= 0
                and frame >= self._batch_end - PREFETCH_THRESHOLD
                and self._batch_end + 1 < self._frame_count):
            self._launch(self._batch_end + 1)

    def _launch(self, frame):
        self._cancel()
        self._batch_start = frame
        count = min(BATCH_SIZE, self._frame_count - frame)
        self._batch_end = frame + count - 1
        self._next_frame = frame
        self._buffer = bytearray()
        # Own the process at application level: source/window deletion while
        # the OS finishes killing FFmpeg must not destroy a running QProcess.
        proc = configure_process(QtCore.QProcess(QtCore.QCoreApplication.instance()))
        proc.readyReadStandardOutput.connect(lambda: self._read(proc))
        proc.finished.connect(lambda *_: self._finished(proc))
        proc.finished.connect(lambda *_: self._retire(proc))
        proc.errorOccurred.connect(lambda *_: self._error(proc))
        proc.setProgram(self._ffmpeg)
        proc.setArguments([
            '-hide_banner', '-loglevel', 'error', '-nostdin',
            '-ss', '{:.7f}'.format(frame / self._fps), '-i', self._source,
            '-an', '-frames:v', str(count),
            '-vf', "scale='min({},iw)':-2".format(DECODE_WIDTH),
            '-f', 'image2pipe', '-vcodec', 'mjpeg', '-q:v', '4', 'pipe:1'])
        self._proc = proc
        proc.start()

    def _read(self, proc):
        if proc is not self._proc:
            return
        self._buffer.extend(bytes(proc.readAllStandardOutput()))
        blobs, self._buffer = _split_jpegs(self._buffer)
        for blob in blobs:
            if self._next_frame > self._batch_end:
                break
            image = QtGui.QImage.fromData(blob, 'JPG')
            frame = self._next_frame
            self._next_frame += 1
            if image.isNull():
                continue
            pixmap = QtGui.QPixmap.fromImage(image)
            old = self._cache.pop(frame, None)
            if old is not None:
                self._cache_bytes -= old.width() * old.height() * 4
            self._cache[frame] = pixmap
            self._cache_bytes += pixmap.width() * pixmap.height() * 4
            while len(self._cache) > CACHE_FRAMES or self._cache_bytes > CACHE_BYTES:
                removable = next((key for key in self._cache
                                  if not (self._loop_start <= key < self._loop_start + 8)),
                                 None)
                if removable is None:
                    break
                victim = self._cache.pop(removable)
                self._cache_bytes -= victim.width() * victim.height() * 4
            self.frameAvailable.emit(frame)

    def _error(self, proc):
        if proc is self._proc and proc.error() == QtCore.QProcess.FailedToStart:
            self._proc = None
            proc.deleteLater()
            self._failed = True
            if not self._error_reported:
                self._error_reported = True
                self.errorText.emit('FFmpeg decoder could not start. Check the FFmpeg installation.')

    def _finished(self, proc):
        if proc is self._proc:
            self._read(proc)
            count = self._next_frame - self._batch_start
            exit_error = proc.exitStatus() != QtCore.QProcess.NormalExit or proc.exitCode() != 0
            self._proc = None
            self._buffer = bytearray()
            if exit_error or count <= 0:
                # A broken decoder must not be restarted every 8ms.
                self._failed = True
                if not self._error_reported:
                    self._error_reported = True
                    message = bytes(proc.readAllStandardError()).decode('utf-8', 'replace')[-700:]
                    self.errorText.emit('FFmpeg decoder failed: ' + (message or 'No frames decoded.'))

    def _retire(self, proc):
        self._retired.discard(proc)
        try:
            proc.deleteLater()
        except RuntimeError:
            pass

    def _cancel(self):
        if self._proc is not None:
            self._retired.add(self._proc)
            _stop_process(self._proc)
            self._proc = None
        self._buffer = bytearray()

    def shutdown(self):
        self._cancel()
        self._cache.clear()
        self._cache_bytes = 0


class FramePump(QtCore.QObject):
    """Elapsed-clock playback that holds the last good frame during buffering."""
    frameChanged = Signal(int)
    stopped = Signal()

    def __init__(self, source, fps, parent=None):
        QtCore.QObject.__init__(self, parent)
        self._source = source
        self._fps = max(0.001, float(fps))
        self._timer = QtCore.QTimer(self)
        self._timer.setTimerType(QtCore.Qt.PreciseTimer)
        self._timer.setInterval(8)
        self._timer.timeout.connect(self._tick)
        self._clock = QtCore.QElapsedTimer()
        self._anchor = 0
        self.frame = 0
        self.in_frame = 0
        self.out_frame = 0
        self.loop = False
        self.speed = 1.0

    def is_playing(self):
        return self._timer.isActive()

    def play(self):
        if self._timer.isActive():
            return
        if self.in_frame >= self.out_frame:
            self.seek(self.in_frame)
            self.stopped.emit()
            return
        if self.frame >= self.out_frame:
            self.seek(self.in_frame)
        self._anchor = self.frame
        self._clock.start()
        self._source.ensure(self.frame)
        self._source.ensure(min(self.frame + 6, self.out_frame))
        self._timer.start()

    def pause(self):
        if self._timer.isActive():
            self._timer.stop()
            self.stopped.emit()

    def set_speed(self, speed):
        self.speed = max(0.01, float(speed))
        if self.is_playing():
            self._anchor = self.frame
            self._clock.restart()

    def seek(self, frame):
        self.frame = int(utils.clamp(frame, self.in_frame, self.out_frame))
        self._source.ensure(self.frame)
        if self.is_playing():
            self._anchor = self.frame
            self._clock.restart()
        self.frameChanged.emit(self.frame)

    def _tick(self):
        if self.in_frame >= self.out_frame:
            self.pause()
            return
        if self._source.get(self.frame) is None:
            self._source.ensure(self.frame)
            self._anchor = self.frame
            self._clock.restart()
            return
        advance = int(self._clock.elapsed() * self._fps * self.speed / 1000.0)
        candidate = self._anchor + advance
        if candidate <= self.frame:
            self._source.ensure(min(self.frame + 8, self.out_frame))
            return
        if candidate > self.out_frame:
            if not self.loop:
                candidate = self.out_frame
            else:
                candidate = self.in_frame + (candidate - self.out_frame - 1) % (
                    self.out_frame - self.in_frame + 1)
        self._source.ensure(candidate)
        if self._source.get(candidate) is None:
            self._anchor = self.frame
            self._clock.restart()
            return
        self.frame = candidate
        self.frameChanged.emit(self.frame)
        if not self.loop and self.frame >= self.out_frame:
            self.pause()
        else:
            self._source.ensure(min(self.frame + 8, self.out_frame))

    def pixmap(self):
        return self._source.get(self.frame)
