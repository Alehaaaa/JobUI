# -*- coding: utf-8 -*-
"""MarkedTimelineSlider: scrub track with two optional, stackable lanes.

Layout, top to bottom, each lane independently toggleable:
    [ thumbnail strip ]   (optional)
    [ waveform        ]   (optional)
    [ scrub track     ]   (always; range highlight + playhead)

All lanes share one time axis, so a thumbnail, its waveform column and the
playhead line up at the same frame.
"""
from __future__ import absolute_import

from .qtcompat import QtCore, QtGui, QtWidgets, Signal
from . import style, utils

MARGIN = 8
TRACK_H = 16
WAVE_H = 24


class MarkedTimelineSlider(QtWidgets.QWidget):
    scrubbed = Signal(int)

    def __init__(self, parent=None):
        QtWidgets.QWidget.__init__(self, parent)
        self._count = 1
        self._frame = 0
        self._in = 0
        self._out = 0
        self._peaks = []
        self._thumbs = {}
        self._thumb_total = 0
        self._thumb_h = 36
        self._show_thumbs = True
        self._show_wave = True
        self.setMouseTracking(True)
        self._relayout()

    # -- configuration ----------------------------------------------------
    def set_frame_count(self, count):
        self._count = max(1, int(count))
        self._out = self._count - 1
        self.update()

    def set_frame(self, frame):
        self._frame = int(utils.clamp(frame, 0, self._count - 1))
        self.update()

    def set_range(self, in_frame, out_frame):
        self._in, self._out = int(in_frame), int(out_frame)
        self.update()

    def set_waveform(self, peaks):
        self._peaks = list(peaks or [])
        self.update()

    def clear_waveform(self):
        self._peaks = []
        self.update()

    def begin_thumbnails(self, total, thumb_h):
        self._thumbs = {}
        self._thumb_total = max(1, total)
        self._thumb_h = max(24, int(thumb_h))
        self._relayout()

    def add_thumbnail(self, ordinal, pixmap):
        self._thumbs[int(ordinal)] = pixmap
        self.update()

    def clear_thumbnails(self):
        self._thumbs = {}
        self._thumb_total = 0
        self.update()

    def set_thumbnails_visible(self, visible):
        self._show_thumbs = bool(visible)
        self._relayout()

    def set_waveform_visible(self, visible):
        self._show_wave = bool(visible)
        self._relayout()

    def thumbnails_visible(self):
        return self._show_thumbs

    def waveform_visible(self):
        return self._show_wave

    # -- geometry ---------------------------------------------------------
    def _relayout(self):
        height = TRACK_H
        if self._show_wave:
            height += WAVE_H
        if self._show_thumbs:
            height += self._thumb_h
        self.setFixedHeight(height)
        self.updateGeometry()
        self.update()

    def _inner_width(self):
        return max(1, self.width() - 2 * MARGIN)

    def _x_for(self, frame):
        if self._count <= 1:
            return MARGIN
        return MARGIN + self._inner_width() * frame / float(self._count - 1)

    def _frame_for(self, x):
        ratio = (x - MARGIN) / float(self._inner_width())
        return int(round(utils.clamp(ratio, 0.0, 1.0) * (self._count - 1)))

    def _lane_rects(self):
        """Return (thumb_rect, wave_rect, track_rect); empty rects when hidden."""
        top = 0
        empty = QtCore.QRect()
        thumb = empty
        wave = empty
        if self._show_thumbs:
            thumb = QtCore.QRect(0, top, self.width(), self._thumb_h)
            top += self._thumb_h
        if self._show_wave:
            wave = QtCore.QRect(0, top, self.width(), WAVE_H)
            top += WAVE_H
        track = QtCore.QRect(0, top, self.width(), TRACK_H)
        return thumb, wave, track

    # -- painting ---------------------------------------------------------
    def paintEvent(self, event):
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.Antialiasing, True)
        thumb_rect, wave_rect, track_rect = self._lane_rects()
        if not thumb_rect.isEmpty():
            self._paint_thumbs(painter, thumb_rect)
        if not wave_rect.isEmpty():
            self._paint_wave(painter, wave_rect)
        self._paint_track(painter, track_rect)
        self._paint_playhead(painter)
        painter.end()

    def _paint_thumbs(self, painter, rect):
        painter.fillRect(rect, QtGui.QColor(style.THUMB_FRAME))
        if not self._thumbs:
            return
        inner = self._inner_width()
        cell = inner / float(self._thumb_total)
        for ordinal, pixmap in self._thumbs.items():
            x = MARGIN + ordinal * cell
            target = QtCore.QRectF(x, rect.top() + 1, cell + 1, rect.height() - 2)
            painter.drawPixmap(target, pixmap, QtCore.QRectF(pixmap.rect()))

    def _paint_wave(self, painter, rect):
        painter.fillRect(rect, QtGui.QColor(style.TRACK))
        if not self._peaks:
            return
        inner = self._inner_width()
        mid = rect.top() + rect.height() / 2.0
        half = rect.height() / 2.0 - 2
        count = len(self._peaks)
        painter.setPen(QtGui.QColor(style.WAVE))
        for px in range(int(inner)):
            peak = self._peaks[int(px / inner * count)]
            amp = peak * half
            x = MARGIN + px
            painter.drawLine(QtCore.QPointF(x, mid - amp), QtCore.QPointF(x, mid + amp))

    def _paint_track(self, painter, rect):
        well = QtCore.QRectF(MARGIN, rect.top() + rect.height() / 2.0 - 2,
                             self._inner_width(), 4)
        painter.fillRect(well, QtGui.QColor(style.TRACK))
        x_in, x_out = self._x_for(self._in), self._x_for(self._out)
        painter.fillRect(QtCore.QRectF(x_in, well.top(), max(1.0, x_out - x_in), well.height()),
                         QtGui.QColor(style.ACCENT))

    def _paint_playhead(self, painter):
        x = self._x_for(self._frame)
        painter.setPen(QtGui.QPen(QtGui.QColor(style.ACCENT_HI), 1))
        painter.drawLine(QtCore.QPointF(x, 0), QtCore.QPointF(x, self.height()))
        handle = QtGui.QPolygonF([
            QtCore.QPointF(x, self.height() - TRACK_H + 2),
            QtCore.QPointF(x - 5, self.height() - TRACK_H - 4),
            QtCore.QPointF(x + 5, self.height() - TRACK_H - 4)])
        painter.setBrush(QtGui.QColor(style.ACCENT_HI))
        painter.setPen(QtCore.Qt.NoPen)
        painter.drawPolygon(handle)

    # -- interaction ------------------------------------------------------
    def mousePressEvent(self, event):
        if event.button() == QtCore.Qt.LeftButton:
            self.scrubbed.emit(self._frame_for(event.pos().x()))
            event.accept()

    def mouseMoveEvent(self, event):
        if event.buttons() & QtCore.Qt.LeftButton:
            self.scrubbed.emit(self._frame_for(event.pos().x()))
            event.accept()

    def resizeEvent(self, event):
        QtWidgets.QWidget.resizeEvent(self, event)
        self.update()
