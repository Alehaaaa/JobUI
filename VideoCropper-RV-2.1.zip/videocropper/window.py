# -*- coding: utf-8 -*-
"""VideoCropperWindow: the dock-free dialog that wires the pieces together.

The layout follows RV's shape -- a menu bar on top where every visual item and
playback setting has a home, a maximal central viewer, a slim side panel for
crop/output data, and a thin transport at the bottom. The window owns no
playback logic; it binds widgets and menu actions to the Player's state and to
the ffmpeg jobs (waveform, thumbnails, tracking, export).
"""
from __future__ import absolute_import

import bisect
import html
import os
import shutil

from .qtcompat import (QtCore, QtGui, QtWidgets, QAction, QActionGroup, QShortcut,
                       HAVE_MULTIMEDIA, maya_main_window)
from . import style, utils, ffmpegtools, tracking
from .surface import PlaybackSurface
from .timeline import MarkedTimelineSlider
from .player import Player
from .waveform import WaveformJob
from .thumbnails import ThumbnailStripJob
from .tracking import TrackingJob
from .export import ExportOptionsDialog, ExportJob

THUMB_LANE_H = 36
SPEEDS = (0.25, 0.5, 1.0, 1.5, 2.0)


class VideoCropperWindow(QtWidgets.QDialog):
    _instance = None
    _object_name = 'FramestoreVideoCropper'

    def __init__(self, parent=None):
        QtWidgets.QDialog.__init__(self, parent)
        self.setObjectName(self._object_name)
        self.setWindowTitle('Video Cropper')
        self.resize(1080, 640)
        self.setAttribute(QtCore.Qt.WA_DeleteOnClose, True)

        self.ffmpeg = ffmpegtools.find_binary('ffmpeg')
        self.ffprobe = ffmpegtools.find_binary('ffprobe')

        self.info = None
        self._closed = False

        # tracking state
        self.tracking_enabled = False
        self.tracked_centers = {}
        self.tracking_size = None
        self.tracking_offset = QtCore.QPointF(0.0, 0.0)
        self._applying_tracked = False
        self._tracking_job = None

        # lane generation state
        self._waveform_ready = False
        self._thumbs_ready = False

        # export state
        self._export_job = None
        self._export_queue = []
        self._export_done = []
        self._export_failed = False

        self.surface = PlaybackSurface()
        self._build_ui()

        self.player = Player(self.ffmpeg, self.surface, self)
        self.waveform_job = WaveformJob(self.ffmpeg, self)
        self.thumb_job = ThumbnailStripJob(self.ffmpeg, self)

        self._connect()
        self._set_enabled(False)
        self.surface.set_placeholder_visible(True)

    # ------------------------------------------------------------------ UI
    def _build_ui(self):
        root = QtWidgets.QVBoxLayout(self)
        root.setContentsMargins(4, 4, 4, 4)
        root.setSpacing(3)
        root.setMenuBar(self._build_menu())

        self._splitter = QtWidgets.QSplitter(QtCore.Qt.Horizontal)
        self._splitter.addWidget(self.surface)
        self.side = self._build_side()
        self._splitter.addWidget(self.side)
        self._splitter.setSizes([860, 220])
        self.side.hide()
        root.addWidget(self._splitter, 1)

        self.timeline = MarkedTimelineSlider()
        root.addWidget(self.timeline)
        root.addLayout(self._build_transport())

        self.progress = QtWidgets.QProgressBar()
        self.progress.hide()
        root.addWidget(self.progress)

        self.status_lbl = QtWidgets.QLabel('Import media to begin.')
        self.status_lbl.setOpenExternalLinks(True)
        self.status_lbl.setTextFormat(QtCore.Qt.RichText)
        root.addWidget(self.status_lbl)

    def _build_menu(self):
        bar = QtWidgets.QMenuBar(self)

        def action(menu, text, slot=None, checkable=False, checked=False, shortcut=None):
            act = QAction(text, self)
            act.setCheckable(checkable)
            act.setChecked(checked)
            if shortcut:
                act.setShortcut(QtGui.QKeySequence(shortcut))
            if slot is not None:
                if checkable:
                    act.toggled.connect(slot)
                else:
                    # triggered(checked) passes a bool; swallow it for no-arg slots.
                    act.triggered.connect(lambda *_: slot())
            menu.addAction(act)
            return act

        file_menu = bar.addMenu('File')
        self.act_import = action(file_menu, 'Import Media…', self._choose_media, shortcut='I')
        self.act_export = action(file_menu, 'Export Media…', self._export, shortcut='E')
        file_menu.addSeparator()
        action(file_menu, 'Close', self.close)

        view_menu = bar.addMenu('View')
        self.act_thumbs = action(view_menu, 'Thumbnail Strip', self._toggle_thumbnails, checkable=True, checked=True)
        self.act_wave = action(view_menu, 'Audio Waveform', self._toggle_waveform, checkable=True, checked=True)
        view_menu.addSeparator()
        self.act_crop = action(view_menu, 'Crop Overlay', self.surface.set_crop_visible,
                               checkable=True, checked=True)
        self.act_side = action(view_menu, 'Side Panel', self._toggle_side,
                               checkable=True, checked=False)

        play_menu = bar.addMenu('Playback')
        self.act_loop = action(play_menu, 'Loop', self.player_set_loop, checkable=True,
                               shortcut='L')
        speed_menu = play_menu.addMenu('Speed')
        self._speed_group = QActionGroup(self)
        self.speed_actions = {}
        for value in SPEEDS:
            act = QAction('{:g}×'.format(value), self)
            act.setCheckable(True)
            act.setChecked(value == 1.0)
            act.triggered.connect(lambda _=False, v=value: self._set_speed(v))
            self._speed_group.addAction(act)
            speed_menu.addAction(act)
            self.speed_actions[value] = act

        xform_menu = bar.addMenu('Transform')
        self.act_flip_h = action(xform_menu, 'Flip X', self._on_flip_changed, checkable=True,
                                 shortcut='Shift+X')
        self.act_flip_v = action(xform_menu, 'Flip Y', self._on_flip_changed, checkable=True,
                                 shortcut='Shift+Y')

        help_menu = bar.addMenu('Help')
        action(help_menu, 'About Video Cropper', self._about)
        return bar

    def _build_side(self):
        side = QtWidgets.QWidget()
        side.setObjectName('vcSide')
        side.setMinimumWidth(220)
        side.setMaximumWidth(320)
        column = QtWidgets.QVBoxLayout(side)
        column.setContentsMargins(10, 10, 10, 10)
        column.setSpacing(4)

        def heading(text):
            label = QtWidgets.QLabel(text.upper())
            font = label.font()
            font.setBold(True)
            label.setFont(font)
            column.addWidget(label)

        heading('Media')
        self.media_lbl = QtWidgets.QLabel('No media')
        self.media_lbl.setWordWrap(True)
        column.addWidget(self.media_lbl)

        heading('Crop')
        self.crop_lbl = QtWidgets.QLabel('None — full frame')
        self.crop_lbl.setWordWrap(True)
        column.addWidget(self.crop_lbl)

        heading('Output resolution')
        resolution = QtWidgets.QHBoxLayout()
        self.out_w_le = QtWidgets.QLineEdit()
        self.out_h_le = QtWidgets.QLineEdit()
        resolution.addWidget(self.out_w_le)
        resolution.addWidget(QtWidgets.QLabel('×'))
        resolution.addWidget(self.out_h_le)
        column.addLayout(resolution)

        if tracking.HAVE_CV2:
            heading('Tracking')
            track_row = QtWidgets.QHBoxLayout()
            self.track_btn = QtWidgets.QPushButton('Track Forward')
            self.clear_track_btn = QtWidgets.QPushButton('Clear')
            track_row.addWidget(self.track_btn, 1)
            track_row.addWidget(self.clear_track_btn)
            column.addLayout(track_row)
            self.tracking_lbl = QtWidgets.QLabel('No tracking')
            column.addWidget(self.tracking_lbl)
        else:
            self.track_btn = self.clear_track_btn = self.tracking_lbl = None

        heading('Export fps')
        self.fps_combo = QtWidgets.QComboBox()
        self.fps_combo.addItem('24 fps', '24')
        self.fps_combo.addItem('Original', 'source')
        column.addWidget(self.fps_combo)
        column.addStretch(1)
        return side

    def _build_transport(self):
        row = QtWidgets.QHBoxLayout()
        row.setSpacing(3)
        row.setContentsMargins(0, 1, 0, 1)
        button_names = (
            ('first_btn', 'SP_MediaSkipBackward', 'First frame'),
            ('prev_btn', 'SP_MediaSeekBackward', 'Previous frame'),
            ('play_btn', 'SP_MediaPlay', 'Play / pause (Space)'),
            ('next_btn', 'SP_MediaSeekForward', 'Next frame'),
            ('last_btn', 'SP_MediaSkipForward', 'Last frame'),
        )
        for name, icon_name, hint in button_names:
            btn = QtWidgets.QToolButton()
            btn.setFixedSize(27, 25)
            btn.setAutoRaise(True)
            btn.setToolTip(hint)
            btn.setIcon(self._transport_icon(icon_name))
            setattr(self, name, btn)
            row.addWidget(btn)

        self.speed_combo = QtWidgets.QComboBox()
        for value in SPEEDS:
            self.speed_combo.addItem('{:g}×'.format(value), value)
        self.speed_combo.setCurrentIndex(SPEEDS.index(1.0))
        self.speed_combo.setFixedWidth(66)
        row.addSpacing(6)
        row.addWidget(self.speed_combo)
        row.addStretch()

        self.frame_lbl = QtWidgets.QLabel('0 / 0')
        self.frame_lbl.setMinimumWidth(85)
        self.frame_lbl.setAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
        row.addWidget(self.frame_lbl)
        row.addSpacing(8)
        self.in_spin = QtWidgets.QSpinBox()
        self.out_spin = QtWidgets.QSpinBox()
        for widget, prefix in ((self.in_spin, 'In '), (self.out_spin, 'Out ')):
            widget.setPrefix(prefix)
            widget.setFixedWidth(98)
            widget.setToolTip('Playback and export {} frame'.format(prefix.strip()))
            row.addWidget(widget)
        return row

    def _transport_icon(self, name):
        enum = getattr(QtWidgets.QStyle, name, None)
        if enum is None and hasattr(QtWidgets.QStyle, 'StandardPixmap'):
            enum = getattr(QtWidgets.QStyle.StandardPixmap, name, None)
        return self.style().standardIcon(enum) if enum is not None else QtGui.QIcon()

    # -------------------------------------------------------------- wiring
    def _connect(self):
        self.player.frameChanged.connect(self._on_frame_changed)
        self.player.playingChanged.connect(self._on_playing_changed)
        self.player.errorText.connect(
            lambda m: self.status_lbl.setText('Playback error: ' + html.escape(m)))

        self.surface.cropChanged.connect(self._on_crop_changed)
        self.surface.scrubRequested.connect(lambda d: self._scrub(self.player.current_frame + d))
        self.surface.mediaDropped.connect(self._load_path)
        self.surface.importRequested.connect(self._choose_media)
        self.timeline.scrubbed.connect(self._scrub)

        self.in_spin.valueChanged.connect(self._range_changed)
        self.out_spin.valueChanged.connect(self._range_changed)
        self.first_btn.clicked.connect(lambda: self._scrub(self.player.in_frame))
        self.last_btn.clicked.connect(lambda: self._scrub(self.player.out_frame))
        self.prev_btn.clicked.connect(lambda: self._scrub(self.player.current_frame - 1))
        self.next_btn.clicked.connect(lambda: self._scrub(self.player.current_frame + 1))
        self.play_btn.clicked.connect(self.player.toggle)
        self.speed_combo.currentIndexChanged.connect(
            lambda: self._set_speed(float(self.speed_combo.currentData() or 1.0)))

        if self.track_btn is not None:
            self.track_btn.clicked.connect(self._track_forward)
            self.clear_track_btn.clicked.connect(lambda: self._clear_tracking())

        self.waveform_job.ready.connect(self.timeline.set_waveform)
        self.thumb_job.started.connect(
            lambda total: self.timeline.begin_thumbnails(total, THUMB_LANE_H))
        self.thumb_job.produced.connect(self.timeline.add_thumbnail)

        space = QShortcut(QtGui.QKeySequence('Space'), self)
        space.setContext(QtCore.Qt.WidgetWithChildrenShortcut)
        space.activated.connect(self.player.toggle)

    # --------------------------------------------------------- media load
    def _choose_media(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self, 'Import media', os.path.expanduser('~'),
            'Media (*.mp4 *.mov *.mkv *.webm *.avi *.m4v *.jpg *.jpeg *.png *.tga *.exr);;All files (*)')
        if path:
            self._load_path(path)

    def _load_path(self, path):
        """Shared entry point for the file dialog, the placeholder, and drops."""
        if self._closed or (self._export_job is not None and self._export_job.isRunning()):
            return
        try:
            info = ffmpegtools.probe(self.ffprobe, QtGui.QImageReader, path)
        except Exception as exc:
            QtWidgets.QMessageBox.critical(self, 'Import failed', str(exc))
            return
        self._load(info)

    def _load(self, info):
        self._cancel_tracking_job()
        self.info = info
        self.surface.set_placeholder_visible(False)
        self._clear_tracking(update=False)
        self.waveform_job.cancel()
        self.thumb_job.cancel()
        self._waveform_ready = self._thumbs_ready = False
        self.timeline.clear_waveform()
        self.timeline.clear_thumbnails()

        for act in (self.act_flip_h, self.act_flip_v):
            act.blockSignals(True)
            act.setChecked(False)
            act.blockSignals(False)
        self.surface.set_flip(False, False)

        self.player.load(info)
        self.player.set_loop(self.act_loop.isChecked())
        self.player.set_speed(float(self.speed_combo.currentData() or 1.0))

        self.setWindowTitle('Video Cropper — {}'.format(os.path.basename(info.path)))
        self.media_lbl.setToolTip(info.path)
        self.media_lbl.setText('{} × {}\n{:g} fps  ·  {} frames'.format(
            info.width, info.height, info.fps, info.frame_count))
        self.out_w_le.setText(str(info.width))
        self.out_h_le.setText(str(info.height))

        self.timeline.set_frame_count(info.frame_count)
        self.timeline.set_range(0, info.frame_count - 1)
        self.timeline.set_frame(0)
        for spin, value in ((self.in_spin, 0), (self.out_spin, info.frame_count - 1)):
            spin.blockSignals(True)
            spin.setRange(0, info.frame_count - 1)
            spin.setValue(value)
            spin.blockSignals(False)

        self._set_enabled(True)
        if not HAVE_MULTIMEDIA and not info.is_sequence:
            self.status_lbl.setText('QtMultimedia unavailable — using frame stepping. '
                                    'Drag to crop. Right-click viewport to clear.')
        else:
            self.status_lbl.setText('Drag to crop. Right-click viewport to clear crop.')
        if self.act_thumbs.isChecked():
            self._request_thumbnails()
        if self.act_wave.isChecked():
            self._request_waveform()

    def _set_enabled(self, on):
        widgets = [self.timeline, self.in_spin, self.out_spin, self.first_btn, self.prev_btn,
                   self.play_btn, self.next_btn, self.last_btn, self.speed_combo,
                   self.fps_combo, self.out_w_le, self.out_h_le]
        if self.track_btn is not None:
            widgets += [self.track_btn, self.clear_track_btn]
        for widget in widgets:
            widget.setEnabled(on)
        for act in (self.act_export, self.act_thumbs, self.act_wave, self.act_crop,
                    self.act_loop, self.act_flip_h, self.act_flip_v):
            act.setEnabled(on)

    # ----------------------------------------------------------- playback
    def player_set_loop(self, enabled):
        self.player.set_loop(enabled)

    def _set_speed(self, value):
        self.player.set_speed(value)
        if self.speed_combo.currentData() != value:
            index = self.speed_combo.findData(value)
            if index >= 0:
                self.speed_combo.blockSignals(True)
                self.speed_combo.setCurrentIndex(index)
                self.speed_combo.blockSignals(False)
        act = self.speed_actions.get(value)
        if act is not None and not act.isChecked():
            act.setChecked(True)

    def _scrub(self, frame):
        if self.player.playing:
            self.player.pause()
        self.player.seek(frame)

    def _on_frame_changed(self, frame):
        self.frame_lbl.setText('{} / {}'.format(frame, self.player.frame_count - 1))
        self.timeline.set_frame(frame)
        if self.tracking_enabled:
            self._apply_tracked_crop()

    def _on_playing_changed(self, playing):
        self.play_btn.setIcon(self._transport_icon('SP_MediaPause' if playing else 'SP_MediaPlay'))

    def _range_changed(self, *args):
        self.player.set_range(self.in_spin.value(), self.out_spin.value())
        self.timeline.set_range(self.player.in_frame, self.player.out_frame)

    # ------------------------------------------------------- view toggles
    def _toggle_side(self, visible):
        self.side.setVisible(visible)

    def _toggle_thumbnails(self, visible):
        self.timeline.set_thumbnails_visible(visible)
        if visible and self.info is not None and not self._thumbs_ready:
            self._request_thumbnails()

    def _toggle_waveform(self, visible):
        self.timeline.set_waveform_visible(visible)
        if visible and self.info is not None and not self._waveform_ready:
            self._request_waveform()

    def _request_thumbnails(self):
        self._thumbs_ready = True
        aspect = self.info.width / float(max(1, self.info.height))
        cell = max(16, THUMB_LANE_H * aspect)
        inner = max(1, self.timeline.width() - 16)
        count = int(utils.clamp(inner / cell, 6, 16))
        count = min(count, self.info.frame_count)
        # begin_thumbnails is driven by the job's `started` signal.
        self.thumb_job.request(self.info, count, THUMB_LANE_H)

    def _request_waveform(self):
        self._waveform_ready = True
        if self.info.is_sequence:
            self.timeline.set_waveform([])
            return
        self.waveform_job.request(self.info.path, self.info.duration)

    # --------------------------------------------------------------- crop
    def _on_crop_changed(self, rect):
        crop = self.surface.crop()
        if crop is None:
            self.crop_lbl.setText('None — full frame')
            if self.tracking_enabled and not self._applying_tracked:
                self._clear_tracking(update=False)
            return
        x, y, w, h = crop
        self.crop_lbl.setText('{}, {}  ·  {} × {}'.format(x, y, w, h))
        if not self._applying_tracked:
            self.out_w_le.setText(str(w))
            self.out_h_le.setText(str(h))
            if self.tracking_enabled:
                center = self._nearest_center(self.player.current_frame)
                if center:
                    self.tracking_size = (w, h)
                    self.tracking_offset = QtCore.QPointF(
                        x + w / 2.0 - center[0], y + h / 2.0 - center[1])

    def _on_flip_changed(self, *args):
        self.surface.set_flip(self.act_flip_h.isChecked(), self.act_flip_v.isChecked())
        if self.tracking_enabled:
            self._clear_tracking(update=False)
            self.status_lbl.setText('Transform changed: tracking cleared.')

    # ----------------------------------------------------------- tracking
    def _cancel_tracking_job(self):
        job = self._tracking_job
        self._tracking_job = None
        if job is None:
            return
        if job.isRunning():
            job.requestInterruption()
        for signal in (job.progress, job.result, job.error):
            try:
                signal.disconnect()
            except (RuntimeError, TypeError):
                pass

    def _clear_tracking(self, update=True):
        self.tracking_enabled = False
        self.tracked_centers = {}
        self.tracking_size = None
        self.tracking_offset = QtCore.QPointF()
        if self.tracking_lbl is not None:
            self.tracking_lbl.setText('No tracking')

    def _nearest_center(self, index):
        if not self.tracked_centers:
            return None
        keys = sorted(self.tracked_centers)
        pos = bisect.bisect_left(keys, int(index))
        if pos == 0:
            key = keys[0]
        elif pos == len(keys):
            key = keys[-1]
        else:
            before, after = keys[pos - 1], keys[pos]
            key = before if index - before <= after - index else after
        return self.tracked_centers[key]

    def _apply_tracked_crop(self):
        fallback = self.surface.crop()
        if fallback is None:
            return
        center = self._nearest_center(self.player.current_frame)
        if center is None:
            return
        w, h = self.tracking_size or (fallback[2], fallback[3])
        cx = center[0] + self.tracking_offset.x()
        cy = center[1] + self.tracking_offset.y()
        x = int(utils.clamp(round(cx - w / 2.0), 0, self.info.width - w))
        y = int(utils.clamp(round(cy - h / 2.0), 0, self.info.height - h))
        self._applying_tracked = True
        try:
            self.surface.set_crop((x, y, w, h))
        finally:
            self._applying_tracked = False

    def _track_forward(self):
        crop = self.surface.crop()
        if crop is None or self.info is None:
            return
        start, end = self.player.current_frame, self.player.out_frame
        if end <= start:
            return
        self.player.pause()
        self._cancel_tracking_job()
        # A cancelled reader can finish after this window is gone.
        job = TrackingJob(
            self.ffmpeg, self.info.path, self.info.sequence_files, self.info.fps,
            start, end, crop, self.act_flip_h.isChecked(), self.act_flip_v.isChecked(),
            QtCore.QCoreApplication.instance())
        self._tracking_job = job
        job.progress.connect(
            lambda p: self.tracking_lbl.setText('Tracking… {}%'.format(p))
            if self._tracking_job is job and not self._closed else None)
        job.result.connect(
            lambda centers, size: self._on_tracking_result(centers, size)
            if self._tracking_job is job and not self._closed else None)
        job.error.connect(
            lambda m: self.status_lbl.setText('Tracking failed: ' + html.escape(m))
            if self._tracking_job is job and not self._closed else None)
        job.finished.connect(
            lambda: self.track_btn.setEnabled(self.info is not None and not self._closed)
            if self._tracking_job is job and not self._closed else None)
        job.finished.connect(job.deleteLater)
        job.start()
        self.track_btn.setEnabled(False)
        self.status_lbl.setText('Tracking crop…')

    def _on_tracking_result(self, centers, crop_size):
        if self._closed or self._tracking_job is None:
            return
        self.tracked_centers = centers
        self.tracking_size = crop_size
        self.tracking_offset = QtCore.QPointF()
        self.tracking_enabled = bool(centers)
        self.tracking_lbl.setText('{} tracked frames'.format(len(centers)))
        self._apply_tracked_crop()
        self.status_lbl.setText('Tracking complete. Move/resize the crop to offset it.')

    # ----------------------------------------------------------- exporting
    def _parse_out_res(self):
        try:
            w, h = int(self.out_w_le.text()), int(self.out_h_le.text())
            if w < 2 or h < 2:
                raise ValueError
            return w, h
        except ValueError:
            raise ValueError('Enter a valid output resolution.')

    def _export(self):
        if self.info is None or self._export_job is not None:
            return
        try:
            out_w, out_h = self._parse_out_res()
        except ValueError as exc:
            QtWidgets.QMessageBox.warning(self, 'Export settings', str(exc))
            return
        # H.264 (yuv420p) requires even dimensions; round down so a crop like
        # 378x427 does not fail the encoder.
        out_w = max(2, out_w - out_w % 2)
        out_h = max(2, out_h - out_h % 2)
        dialog = ExportOptionsDialog(self, self.info.path, os.path.dirname(self.info.path))
        if (dialog.exec() if hasattr(dialog, 'exec') else dialog.exec_()) != QtWidgets.QDialog.Accepted:
            return
        export_fps = self.info.fps if self.fps_combo.currentData() == 'source' else 24.0
        snapshot = dict(
            crop=self.surface.crop(), out_w=out_w, out_h=out_h,
            start=self.player.in_frame, end=self.player.out_frame,
            count=self.player.out_frame - self.player.in_frame + 1,
            fps=export_fps, source_fps=self.info.fps, speed=self.player.speed,
            flip_h=self.act_flip_h.isChecked(), flip_v=self.act_flip_v.isChecked(),
            tracking_enabled=self.tracking_enabled, centers=dict(self.tracked_centers),
            tracking_size=self.tracking_size,
            tracking_offset=(self.tracking_offset.x(), self.tracking_offset.y()))
        conflicts = dialog.conflicts()
        try:
            for target in set(conflicts):
                if os.path.isdir(target) and not os.path.islink(target):
                    shutil.rmtree(target)
                elif os.path.lexists(target):
                    os.unlink(target)
            contexts = []
            for path in dialog.paths():
                os.makedirs(os.path.dirname(path), exist_ok=True)
                contexts.append(dict(snapshot, path=path, sequence=('.####.' in path)))
        except Exception as exc:
            QtWidgets.QMessageBox.critical(self, 'Export path error', str(exc))
            return
        self.player.pause()
        self._export_queue = contexts
        self._export_done = []
        self._export_failed = False
        self._export_next()

    def _export_next(self):
        if not self._export_queue:
            self._export_job = None
            self.progress.hide()
            self._set_enabled(True)
            if not self._export_failed:
                folders = list(dict.fromkeys(os.path.dirname(p) for p in self._export_done))
                links = ['<a href="{}" style="color:{}">{}</a>'.format(
                    QtCore.QUrl.fromLocalFile(os.path.abspath(p)).toString(),
                    style.ACCENT_HI, html.escape(os.path.basename(p) or p)) for p in folders]
                self.status_lbl.setText('Export complete. Open: ' + ' | '.join(links))
            return
        context = self._export_queue.pop(0)
        self._set_enabled(False)
        self.progress.setValue(0)
        self.progress.show()
        self.status_lbl.setText('Exporting {}…'.format(os.path.basename(context['path'])))
        job = ExportJob(self.ffmpeg, self.info.path, self.info.sequence_files,
                        self.info.width, self.info.height, context,
                        QtCore.QCoreApplication.instance())
        job.progress.connect(self.progress.setValue)
        job.result.connect(lambda p=context['path']: self._on_export_done(p))
        job.error.connect(self._on_export_error)
        job.finished.connect(job.deleteLater)
        self._export_job = job
        job.start()

    def _on_export_done(self, path):
        self._export_done.append(path)
        self._export_job = None
        self._export_next()

    def _on_export_error(self, message):
        self._export_failed = True
        self._export_queue = []
        self._export_job = None
        self.progress.hide()
        self._set_enabled(True)
        self.status_lbl.setText('Export failed: ' + html.escape(message))
        QtWidgets.QMessageBox.critical(self, 'Export failed', message)

    # ---------------------------------------------------------- lifecycle
    def _about(self):
        QtWidgets.QMessageBox.about(
            self, 'Video Cropper',
            'Video Cropper\n\nA Maya crop/review tool. QMediaPlayer playback, '
            'ffmpeg-backed thumbnails, waveform and export.')

    def closeEvent(self, event):
        self._closed = True
        if type(self)._instance is self:
            type(self)._instance = None
        self.waveform_job.cancel()
        self.thumb_job.cancel()
        self._cancel_tracking_job()
        if self._export_job is not None and self._export_job.isRunning():
            self._export_job.requestInterruption()
            self._export_job.stop_now()
            for signal in (self._export_job.progress, self._export_job.result,
                           self._export_job.error):
                try:
                    signal.disconnect()
                except (RuntimeError, TypeError):
                    pass
        self.player.shutdown()
        QtWidgets.QDialog.closeEvent(self, event)

    @classmethod
    def show_ui(cls):
        instance = getattr(cls, '_instance', None)
        if instance is not None:
            try:
                instance.close()
            except RuntimeError:
                pass
            cls._instance = None
        window = cls(parent=maya_main_window())
        cls._instance = window
        window.show()
        window.raise_()
        window.activateWindow()
        return window
