# -*- coding: utf-8 -*-
"""Maya Video Cropper.

A crop / review tool for Maya. Native QMediaPlayer / FFmpeg streamed playback, an RV-style menu, a
timeline with optional thumbnail and waveform lanes, optical-flow crop tracking,
and ffmpeg export. Cross-platform; nothing bundled -- relies on Maya's PySide
and a system FFmpeg.

Usage in Maya::

    import videocropper
    videocropper.show()
"""
from __future__ import absolute_import

__version__ = '2.1.0'
__all__ = ['show', 'reload', 'VideoCropperWindow']


def show():
    """Create (or re-create) and raise the Video Cropper window."""
    from .window import VideoCropperWindow
    return VideoCropperWindow.show_ui()


def reload():
    """Fully reload every submodule, then show the window.

    ``importlib.reload(videocropper)`` only re-runs this file; the submodules
    (window, surface, player, ...) stay cached, so UI edits never appear. This
    purges them and shows a fresh window in one call::

        import videocropper
        videocropper.reload()
    """
    import sys
    try:
        from .window import VideoCropperWindow
        if VideoCropperWindow._instance is not None:
            VideoCropperWindow._instance.close()
            VideoCropperWindow._instance = None
    except Exception:
        pass
    for name in [m for m in list(sys.modules) if m.startswith(__name__ + '.')]:
        del sys.modules[name]
    return show()


def __getattr__(name):  # lazy, so importing the package never forces Qt early
    if name == 'VideoCropperWindow':
        from .window import VideoCropperWindow
        return VideoCropperWindow
    raise AttributeError(name)
