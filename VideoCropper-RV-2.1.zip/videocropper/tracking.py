# -*- coding: utf-8 -*-
"""Optional crop tracking via OpenCV optical flow.

Runs off the GUI thread. Produces a per-frame centre for the crop so export can
follow a subject. Degrades cleanly when cv2/numpy are absent.
"""
from __future__ import absolute_import

import subprocess

from .qtcompat import QtCore, Signal
from .ffmpegtools import _no_window_kwargs, media_environment

try:
    import cv2
    import numpy as np
    HAVE_CV2 = True
except Exception:
    cv2 = None
    np = None
    HAVE_CV2 = False


class TrackingJob(QtCore.QThread):
    progress = Signal(int)
    result = Signal(object, object)   # {frame: (cx, cy)}, (w, h)
    error = Signal(str)

    def __init__(self, ffmpeg, path, seq_files, fps, start, end, crop, flip_h, flip_v, parent=None):
        QtCore.QThread.__init__(self, parent)
        self.ffmpeg = ffmpeg
        self.path = path
        self.seq_files = list(seq_files or [])
        self.fps = fps
        self.start = start
        self.end = end
        self.crop = crop
        self.flip_h = flip_h
        self.flip_v = flip_v

    def _read_frame(self, index):
        if self.seq_files:
            return cv2.imread(self.seq_files[index])
        cmd = [self.ffmpeg, '-hide_banner', '-loglevel', 'error', '-nostdin',
               '-ss', '{:.7f}'.format(index / self.fps), '-i', self.path,
               '-frames:v', '1', '-f', 'image2pipe', '-vcodec', 'mjpeg', '-q:v', '3', 'pipe:1']
        kwargs = dict(stderr=subprocess.DEVNULL)
        kwargs.update(_no_window_kwargs())
        kwargs['env'] = media_environment()
        blob = subprocess.check_output(cmd, timeout=12, **kwargs)
        return cv2.imdecode(np.frombuffer(blob, np.uint8), cv2.IMREAD_COLOR)

    def run(self):
        try:
            if not HAVE_CV2:
                raise RuntimeError('OpenCV (cv2) and numpy are required for tracking.')
            x, y, w, h = self.crop
            center = np.array([[[float(x + w / 2), float(y + h / 2)]]], dtype=np.float32)
            previous = None
            centers = {}
            span = self.end - self.start + 1
            for index in range(self.start, self.end + 1):
                if self.isInterruptionRequested():
                    return
                frame = self._read_frame(index)
                if frame is None:
                    raise RuntimeError('Could not decode frame {}'.format(index))
                if self.flip_h:
                    frame = cv2.flip(frame, 1)
                if self.flip_v:
                    frame = cv2.flip(frame, 0)
                gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                if previous is not None:
                    nxt, status, _ = cv2.calcOpticalFlowPyrLK(
                        previous, gray, center, None, winSize=(31, 31), maxLevel=4,
                        criteria=(cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 30, 0.01))
                    if nxt is not None and status is not None and int(status[0, 0]):
                        center = nxt
                centers[index] = (float(center[0, 0, 0]), float(center[0, 0, 1]))
                previous = gray
                if index % 5 == 0:
                    self.progress.emit(int(100 * (index - self.start + 1) / span))
            self.result.emit(centers, (w, h))
        except Exception as exc:
            self.error.emit(str(exc))
