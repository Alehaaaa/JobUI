# -*- coding: utf-8 -*-
"""Backward-compatible shim.

The tool now lives in the ``videocropper`` package next to this file. This shim
keeps existing launch code working::

    import VideoCropper
    VideoCropper.show()
"""
from __future__ import absolute_import

import os
import sys

# Ensure this directory (which holds the videocropper package) is importable.
_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

from videocropper import show, VideoCropperWindow  # noqa: E402,F401


if __name__ == '__main__':
    from videocropper.__main__ import main
    main()
