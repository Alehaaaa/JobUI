VIDEO CROPPER 2.1 — MAYA REVIEW / CROP PLAYER

INSTALL
  Extract this archive to the Maya scripts folder, preserving the paths:
     <maya scripts>/VideoCropper.py
     <maya scripts>/videocropper/__init__.py
     <maya scripts>/videocropper/*.py

LAUNCH (Maya Script Editor, Python)
  import VideoCropper
  VideoCropper.show()

  During development, reload all components:
  import videocropper
  videocropper.reload()

FEATURES
  Compact grey RV-inspired player with crop, trim, zoom-fit display,
  thumbnail strip, audio waveform, frame-stepping, looping and export.
  Poster extraction is not used; the player retains the last decoded frame.
  Playback cache is held in memory and is bounded; no video-frame cache
  directories or persistent preview files are created.
  Optical-flow crop tracking requires OpenCV (cv2 + numpy).

REQUIREMENTS
  Autodesk Maya with PySide2 (Qt5) or PySide6 (Qt6).
  FFmpeg and FFprobe executables available on PATH or at standard locations.
  Preview on PySide2 uses FFmpeg frame streaming. Qt6 uses QMediaPlayer's
  native QVideoSink when available and falls back to frame streaming.
  Audio waveform displays silently; output files are encoded via FFmpeg.

LINUX VFX PIPELINE / GLIBCXX IMPORT ERROR
  Maya may inject an incompatible LD_LIBRARY_PATH or LD_PRELOAD into FFmpeg.
  VideoCropper isolates all media subprocesses from these inherited paths.
  If an installed FFmpeg or FFprobe is incompatible with your studio's
  Linux runtime, set executable overrides BEFORE launching VideoCropper:
     VIDEOCROPPER_FFMPEG=/usr/bin/ffmpeg
     VIDEOCROPPER_FFPROBE=/usr/bin/ffprobe
  Either variable can also point at a directory containing the executable.
  Ask your pipeline team for binaries compatible with your host glibc/GCC.

CACHE / LIFECYCLE
  Approximate video-frame cache ceiling: 144 MiB.
  Image-sequence frame cache ceiling: 128 MiB.
  A small bounded LRU retains generated waveform and thumbnail previews.
  Source changes and shutdown cancel active decoder QProcesses. Export
  temporary directories are removed by their jobs upon normal completion.

VALIDATION
  Syntax and Maya 2024/PySide2 offscreen playback, switching, short trim
  loops, waveform and thumbnails verified. Native Qt6 runtime not installed
  on validation machine; test on a Qt6 Maya host before studio-wide rollout.

CONTENTS
  All .py modules are included. No third-party binaries, caches, EXR sample
  media, developer logs, or generated files are bundled.
